/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.motorph;
//import java.util.Scanner;
//import au.com.bytecode.opencsv.CSVReader;
//import au.com.bytecode.opencsv.CSVParser;

//import static com.mycompany.motorph.CSV_to_table.max_col;
//import static com.mycompany.motorph.CSV_to_table.max_row;
import static com.mycompany.motorph.CSV_to_table.Employee_data;
import java.io.*;
//import java.net.URL;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.util.List;
import javax.swing.*;
public class Motorph {
    static Data_storage_table test_data = new Data_storage_table();
    static String[] Path = {
        "C:\\Users\\user\\Documents\\motorph\\employee_database.csv",
        "C:\\Users\\user\\Documents\\motorph\\working_data\\actual\\employee_database.csv"};
        
    public static void main(String[] args) throws IOException{
        int mode = 0;
        switch(mode){
            case 9: test(); break;
            case 0: CSV_to_table.load_CSV_to_array(Path[0]);  break;
            case 1: CSV_to_table.load_CSV_to_array(Path[1]);  break;
            default:CSV_to_table.load_CSV_to_array(Path[0]);  break;
        }
        
        System.out.println("load employee data");
        System.out.println("loaded");
        
        JFrame maine = new JFrame();
        
        JTable cont = new JTable(Employee_data.getcells(),Employee_data.getHeaders());
        
//cont.

        maine.add(cont);
        maine.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        maine.setUndecorated(false);
        maine.setLocationRelativeTo(null);
        maine.setVisible(false);
        //cont
// maine.up;
       
        System.out.println("load employee data");
        CSV_to_table.save_array_to_CSV("C:\\Users\\user\\Documents\\motorph\\working_data\\actual\\employee_database.csv");
        System.out.println("loaded");
      
       //URL paths = Motorph.("employee_database.csv");
        //path.getFile() C:\Users/user\Downloads\motorph\motorph\src\main\java\com\mycompany\motorph
        
        
    }
    public static void test(){
        
    }
    public static void paycalc(){
    //pay rate * hours worked = gross pay
    // gross pay + (additions and deductibles)
    }
    
    public void reset_table(){
        //for(int a = 0; a <= ,= ){
          //  for(){
            //}
        //}
    }
     public static int readdat(int y) throws IOException{
   
                char g = 'a';
                //int a = 0;
                for(int a = 0; a <= 49; a++){//row
                    System.out.println();
                    for(int b = 0; b <= 49; b++){
                        cells[a][b] = g+ "";
                        System.out.print(cells[a][b]);
                    }
                    g++;
                }
                 System.out.println("case 3");
               // break;
            
//convert .csv file into multi dimmen-array
                int idx = 0 ;
                int row = 0;
                int col = 0;
              //idx = (row * 19)-1 + col;
              //row = (idx+1)/19
              //col = (idx+1)%19
//System.out.print(NL.length);
              while (null != (NL= reader.readNext())) {
                  System.out.print(NL);
                  //System.out.print(" "');
                  
                    //idx++;
              }
                //try{
                for(int a = 0; a <= 49; a++){
                    System.out.println();
                    for(int b = 0; b <= 49; b++){
                        NL = reader.readNext();
                        idx = (row * 19)-1 + col;          
                        cells[row][col] = Arrays.toString(NL);
                        System.out.print(cells[a][b]);
                    }
                    //g++;
                     System.out.println("case 0");
                    }
                //} 
                //catch(Exception e){
                //    System.err.print("sumting wong");}
            }     
        }
        return 0;      
    }

}
/*
JTabbedPane tabbedPane = new JTabbedPane();
//ImageIcon icon = createImageIcon("images/middle.gif");

JComponent panel1 = makeTextPanel("Panel #1");
tabbedPane.addTab("Tab 1", icon, panel1,
                  "Does nothing");
tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);

JComponent panel2 = makeTextPanel("Panel #2");
tabbedPane.addTab("Tab 2", icon, panel2,
                  "Does twice as much nothing");
tabbedPane.setMnemonicAt(1, KeyEvent.VK_2);

JComponent panel3 = makeTextPanel("Panel #3");
tabbedPane.addTab("Tab 3", icon, panel3,
                  "Still does nothing");
tabbedPane.setMnemonicAt(2, KeyEvent.VK_3);

JComponent panel4 = makeTextPanel(
        "Panel #4 (has a preferred size of 410 x 50).");
panel4.setPreferredSize(new Dimension(410, 50));
tabbedPane.addTab("Tab 4", icon, panel4,
                      "Does nothing at all");
tabbedPane.setMnemonicAt(3, KeyEvent.VK_4);

   boolean done = false;
        int a = 0;
        while(!done){
            System.out.println("try "+ a);
            if(a == 10){
                done = true;
                System.out.println("done");}
            else{a++;}
        
    }
        
     
*/
             /* Scanner s = new Scanner(System.in);
            int x;
            x =  2;//s.nextInt();
            readdat(x);
            System.out.println("hello world!");
            public getdata(){}
            public setdata(){}
            public paycalc(){}
            */
            //table.insert_data("hello world!", 50, 50);  