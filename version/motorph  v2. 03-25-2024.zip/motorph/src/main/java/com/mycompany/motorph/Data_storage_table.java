/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.motorph;


/**
 *
 * @author user
 */
public class Data_storage_table {
    private static int          max_row ;    //defines the size of the table
    private static int          max_col ;    //defines the number of collumns
    public  static String []    headers;
    public  static String [][]  table_body = new String[50][50]; //main storage
    public  static String []    entry;//row entry
    public  static String []    list;//collumn entry
    public  static String []    prev_value = {"","",""}; // genral var for storing vlues to be changed or remembered
    public  static boolean      check; // genral varible for storing check values 
    
    //checks
    public void check_input(){
        System.out.println(max_row);
        System.out.println(max_col);
    }
    public boolean check_data_same(String input, int row, int col){
        if(table_body[row][col].equalsIgnoreCase(input) == true){
            return true;}
        else{
            return false;}
    }
    public boolean check_data_empty( int row, int col){
        if(table_body[row][col].equalsIgnoreCase("") == true){
            return true;}
        else if(table_body[row][col].equalsIgnoreCase(null) == true){
            return true;}
        else{
            return false;}
    }
    //basic operations
    public boolean serch_entry_empty(){
        for(int a = 0; a <= max_row;a++){
            if(check_entry_empty(a)== true){
                return true;
            }
            else{
            return false;}
        }
        return false;
    }
    public void write_entry(String[] entry, int row){
        for(int b = 0; b <= max_col; b++){
            write_data(entry[b],row,b);
        }
    }
    public void delete_entry(String[] entry, int row){
        for(int b = 0; b <= max_col; b++){
            write_data(entry[b],row,b);
        }
    }
//cells
    public String read_data(int row, int col){
        prev_value[0] = table_body[row][col];
        return table_body[row][col]; } 
    public String write_data( String input, int row, int col){
        if(check_data_same(input,row,col)==true){
            return "no change, data same";}
        prev_value[0] = table_body [row][col];
        table_body [row][col] = input;
        if(check_data_same(input,row,col)==true){
            return table_body[row][col]+" was changed to "+input;}
        else{return "no change";}
    } 
    public String delete_data(int row, int col){
        prev_value [0] = table_body [row][col];
        table_body [row][col] = "";
        if(check_data_same(prev_value[0],row,col)!=true){
            return "delete: "+table_body[row][col]+" was deleted";}
        else{return "delete: no change";}    
    }
    //compound method below here
    // add data
    // insert entry into first open spot
    
    public String insert_entry(String[] input){
        check = true;
        int b;
        for(int a = 0; a <= max_row;){
            for(int c = 0; c <= 2;){
                for(b = 0; b <= max_col; b++){
                    if(read_data(a,b)!= ""){a++ ; break;}
                    if(check == true){
                    write_data(input[b],a,b);
                    }
                }
                if(b == max_col){check = false;}
                    
            }
            if(check == true){
                check = false;
                a++;}
            elseif(check == false){
                }
        }
        write_data(input, row, col);
        return "";
    }
    public String insert_data(String input){
        for(int a = 0; a <= max_row; a++){
            for(int b = 0; b <= max_col; b++){
                if(table_body[a][b].equalsIgnoreCase("")){
                    write_data(input,a,b);
                    break;}
            }
        }
        return "";
    }
    public void reset_data(){
        for(int a = 0; a <= max_row; a++){
            for(int b = 0; b <= max_col; b++){
                    delete_data(a,b);
                    
            }
        }
    }
    public String add_data_start(String input){
        insert_data(input,1,1);
        return "";
    }
    public String add_data(String input, boolean start_on_end){
        int [] values = new int [4];
        /* values store start and end values, used by the for loop array parser,
        even numbers are for "row" values, odd for "col" values, lower for starting, 
        higher for ending*/
        if(start_on_end == true){
            values[0] = max_row;
            values[1] = max_col;
            values[2] = 0;
            values[3] = 0;
        }
        else{values[0] = 0;
            values[1] = 0;
            values[2] = max_row;
            values[3] = max_row;
        }
        
        for(int a = values[0]; a <= values[1]; a++){
            for(int b = values[2]; b <= values[3]; b++){
                if(table_body[a][b].equalsIgnoreCase("")){
                    write_data(input,a,b);
                    break;}
            }
        }
        return "";
    }
    public static void display_Headers(){
        for(int a = 0; a <= max_col; a++){
            System.out.println(headers[a]);
        }
    }
    
    /**
     * @return the max_row
     */
    public static int       getMax_row() {return max_row;}
    public static int       getMax_col() {
        return max_col;
    }
    public static String[]  getHeaders(){
        return headers;
    }
    public static String[][] getcells(){
        return table_body;
    }
    
    /**
     * @param aMax_row the max_row to set
     */
    public static void setMax_row(int aMax_row) {
        max_row = aMax_row;
    }
    public static void setMax_col(int aMax_col) {
        max_col = aMax_col;
    }
    public static void setHeaders(String[] aHeaders){
        headers = aHeaders;
    }
    
    
    //test values
    public  static String []    testheaders = {"name","age","id"};
    public  static String [][]  testtable_body = {
        {"name1","age1","id1"},
        {"name2","age2","id2"},
        {"name3","age3","id3"},
        {"name4","age4","id4"},
        {"name5","age5","id5"}}; //main storage
    public  static String []    testentry = 
        {"Kurt","21","00125"};//row entry
    public  static String []    testlist =
        {"michael","ivan","sven","itsuki","mercy"};//collumn entry
}
