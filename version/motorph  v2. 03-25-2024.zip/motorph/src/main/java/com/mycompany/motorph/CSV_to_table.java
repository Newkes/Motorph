/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.motorph;

import au.com.bytecode.opencsv.*;
import java.io.*;

/**
 *
 * @author user
 */
public class CSV_to_table {
    static Data_storage_table Employee_data = new Data_storage_table();
    //static String path;
    //static File raw_file = new File(path);
    static int max_row = 0;
    static int max_col = 0;
    
    public static void load_CSV_to_array(String path) throws IOException {
        File raw_file = new File(path);   
        BufferedReader file = new BufferedReader(new FileReader(raw_file));
        CSVReader CSV_file_R = new CSVReader(file); 
        //metadata
        String[] meta  = new String[50];
        meta = CSV_file_R.readNext();
        Employee_data.setMax_row( (max_row = Integer.parseInt(meta[0])-1)+5);
        Employee_data.setMax_col( max_col = Integer.parseInt(meta[1])-1);
        meta = CSV_file_R.readNext();
        Employee_data.setHeaders(meta);
        Employee_data.display_Headers();
        Employee_data.check_input();
        
        //actual
        String[] entry = new String[max_col];
        Employee_data.reset_data();
        for (int a = 0; a <= (max_row-1); a++) {
            entry = CSV_file_R.readNext();
            for (int b = 0; b <= (max_col-1); b++) {
                Employee_data.write_data(entry[b], a, b);
            }
        }
    }
    public static void save_array_to_CSV(String path) throws IOException{
        File raw_file = new File(path);   
        BufferedWriter file = new BufferedWriter(new FileWriter(raw_file));
        CSVWriter CSV_file_w = new CSVWriter( file);
        
        String[] meta  = new String[Employee_data.getMax_col()]; 
        meta[0]= String.valueOf(Employee_data.getMax_row());//( max_row = Integer.parseInt(NL[0])-1);
        meta[1]= String.valueOf(Employee_data.getMax_col());//( max_col = Integer.parseInt(NL[1])-1);
        CSV_file_w.writeNext(meta);
        meta = Employee_data.getHeaders();
        CSV_file_w.writeNext(meta);
        Employee_data.display_Headers();
        Employee_data.check_input();
        
        String[] entry = new String[max_col];
        Employee_data.reset_data();
        for (int a = 0; a <= (max_row-1); a++) {
            for (int b = 0; b <= (max_col-1); b++) {
                System.out.print(a);
                entry[b]= Employee_data.read_data( a, b);
            }
            CSV_file_w.writeNext(entry);
        }
    CSV_file_w.close();
    }
    
    public static void display_table_console(){
        for (int a = 0; a <= max_row; a++) {
            for (int b = 0; b <= max_col; b++) {
                System.out.print(Employee_data.read_data(a, b));
            }
            System.out.println("");
        }
    }
}   

/*
        while ((NL = CSV_file.readNext()) != null) {
            System.out.print(NL[1]);
            //System.out.print(" "');
        }*/
    