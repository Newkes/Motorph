Motorph Setup instructions

step 1. 	open Windows Explorer and Go to Documents. make folder named Motorph.
step 2.a 	inside Motorph, put in provided employee_databse.csv file, or 
step 2.b 	make your own by downloading a copy from the website, opening it in a spreadsheet software, and exporting it as a .CSV file. the name needs to be "employee_database.csv" 
step 3.         open the CSV file, at the top make a new line and put in the "max_row"
                and "max_col", in this format:  max_row,max_col,.
note: max_row and max_col, are to be determined by manualy counting the dimension. feature will be updated in the future.
step 3. 	save file and RUN the program.