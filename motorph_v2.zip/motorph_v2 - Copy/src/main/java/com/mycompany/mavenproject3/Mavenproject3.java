/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;
import tech.tablesaw.api.Table;
import tech.tablesaw.io.*;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 *
 * @author user
 */
public class Mavenproject3 {

    public static void main(String[] args) {
        java.util.logging.Logger.getLogger("tech.tablesaw").setLevel(java.util.logging.Level.ALL);
        System.out.println("Hello World!");
        Table motor = Table.read().csv("./imports/MotorPH_Employee_Data.csv");
        String print = motor.structure().printAll();
        System.out.println(print);
        print = motor.printAll();
        System.out.println(print);
    }
    

}